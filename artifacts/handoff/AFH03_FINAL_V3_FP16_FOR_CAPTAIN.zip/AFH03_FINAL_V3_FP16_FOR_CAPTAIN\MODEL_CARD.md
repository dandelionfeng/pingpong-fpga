﻿# MODEL_CARD — V3 Unified YOLOv8n (FP16 RKNN)

## 基本信息

| 项 | 值 |
|---|---|
| 名称 | V3 Unified YOLOv8n · 3-class ping-pong detector |
| 架构 | YOLOv8n，3 类检测头，单次前向 |
| 交付格式 | **RKNN (FP16)**：`v3_960_fp16_dfl_layout.rknn` |
| RKNN 文件大小 | **13,038,908 B** |
| RKNN SHA256 | `1bcff6ff23f1a26428742e6a8e7c9acaf5b130171dbf2072cbaace6c62bcad0b` |
| 源 ONNX | `pingpong_yolov8n_gray_3cls_v3_960_960.onnx`，12,161,114 B |
| ONNX SHA256 | `b779c88e08f8bd15275e301c00bcbfb9c737fc22fa4ef1c358008f0b932254ba` |
| 输入 | [1,3,960,960] float32（GRAY8→Gray3→letterbox 114→/255） |
| 输出（RKNN） | `dfl` [1,64,18900] + `scores_logits` [1,3,18900] |
| 类别 | 0=ball, 1=hand, 2=racket（固定，不可重排） |
| 转换工具 | rknn-toolkit2 **2.5.0**（WSL2 Ubuntu 24.04 / Python 3.12） |
| target_platform | rk3576 |

## 训练版本

| 项 | 值 |
|---|---|
| 权重 | `artifacts/runs/unified_3cls_v3b/weights/best.pt` |
| 权重 SHA256 | `35e72c114e5c0fe5dc822cd826a5aa6be303bc6516d38317979b71bc5e455b23` |
| 数据 | `pingpong_unified_3cls_v4`：train 4,431 图（ball 2,499 / hand 3,698 / racket 4,790 框），val 509 图 |
| 训练配置 | YOLOv8n 960、batch 12、AdamW 3e-4、cos_lr、mosaic 0.2、scale 0.4、seed 42 |
| 实际轮数 / 最佳 | 15 / 16 轮跑满，best epoch 9 |
| 训练耗时 | 约 32 分钟，RTX 4060 Laptop 8.6 GB |
| 初始化 | `pingpong_3cls_v1`（3 类兼容） |

## 精度（509 张固定 val，阈值 ball 0.20 / hand 0.25 / racket 0.25）

| 类别 | Precision | Recall | F1 | AP50 |
|---|---:|---:|---:|---:|
| Ball | 0.810 | 0.510 | 0.626 | 0.487 |
| Hand | 0.692 | 0.559 | 0.618 | 0.507 |
| Racket | 0.764 | 0.756 | 0.760 | 0.691 |

> PC/RKNN 模拟器结果，**非板端实测**。

## 已知限制

1. **未在 AFH03 上验证**：无实物，NPU 精度与 FPS 未测。
2. **C++ 未编译**：本机无编译器；算法在 Python 侧数值核验过。
3. **OV9281 未接入**：仅支持离线 GRAY8 帧。
4. **Ball Recall 0.510 偏低**：球在 960 输入下仅 9.6–16.9 px（原图 19–34 px），是长期瓶颈；
   已试过 1280 训练、P2 检测头、小球过采样、原图滑窗四条路线，均未超过 V3。
5. **验证集非独立测试集**：V2–V7 多轮用于选型，存在开发集偏差。
6. **FP16 而非 INT8**：INT8 版本 Ball Recall 0.470（差 0.49 门槛 2 点），故未作为默认交付。
   若需要更小/更快的模型，INT8 版与其修复报告在仓库
   `artifacts/rknn_deployment/v3_960_int8_v2/`。
7. **单模型契约**：本包程序独立输出三类；接入正式判罚链路需 B 模块评审（BallTrack 与
   YOLO 的 ball 会形成双源）。

## 复现

```bash
# 用 rknn-toolkit2 2.5.0（Linux）
python3 - <<'PY'
from rknn.api import RKNN
r = RKNN(verbose=False)
r.config(target_platform='rk3576', mean_values=[[0,0,0]],
         std_values=[[255,255,255]], optimization_level=3)
assert r.load_onnx(model='pingpong_yolov8n_gray_3cls_v3_960_960.onnx') == 0
assert r.build(do_quantization=False) == 0        # FP16
r.export_rknn('v3_960_fp16_dfl_layout.rknn')
PY
```
