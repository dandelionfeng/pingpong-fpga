# AFH03 / RK3576J 乒乓球三分类检测器 · 最终交付说明

**模型：V3 Unified YOLOv8n · FP16 RKNN**
**状态：可用于板端联调；板端精度/性能尚未验证（见 `STATUS.md`）**

---

## 1. 这是什么

一个 YOLOv8n 单模型，**一次前向同时输出 ball / hand / racket 三类**，
已转换为 Rockchip RKNN（FP16）供 RK3576J 的 NPU 使用。

| 项 | 值 |
| --- | --- |
| 模型文件 | `v3_960_fp16_dfl_layout.rknn`（13,038,908 B） |
| 转换用 ONNX | `pingpong_yolov8n_gray_3cls_v3_960_960.onnx`（12,161,114 B，PC 端复现/回退用） |
| 输入 | **960 × 960 灰度**（GRAY8 → 复制成 3 通道 → letterbox 填充 114 → /255） |
| 输出 | DFL logits `[1,64,18900]` + 类别 logits `[1,3,18900]`（详见 §4） |
| 类别映射（固定） | **0 = ball，1 = hand，2 = racket** |
| 置信度阈值 | ball **0.20**、hand **0.25**、racket **0.25** |
| NMS | 类内 IoU 0.50，每类最多 60 个框 |

## 2. 精度（509 张固定验证集，PC/RKNN 模拟器评测）

| 类别 | Precision | Recall | F1 | AP50 |
| --- | ---: | ---: | ---: | ---: |
| Ball | 0.810 | 0.510 | 0.626 | 0.487 |
| Hand | 0.692 | 0.559 | 0.618 | 0.507 |
| Racket | 0.764 | 0.756 | 0.760 | 0.691 |

> ⚠ **这是 PC 端 ONNX 与 rknn-toolkit2 模拟器的评测结果，不是 AFH03 板端实测。**
> 板端精度需要在 RK3576J 上重测（方法见 `DEPLOYMENT_GUIDE.md` §6）。

## 3. 怎么用（三种粒度）

### 3.1 PC 端（先确认模型没问题）
```bash
# 用 ONNX 复现评测（需要 onnxruntime + opencv + numpy）
python3 tools/verify_decode_pc.py --onnx pingpong_yolov8n_gray_3cls_v3_960_960.onnx
```
本包不含 PC 评测脚本，PC 端复现请用仓库里的 `artifacts/rknn_deployment/v3_960_int8_v2/`。

### 3.2 板端编译
```bash
cd cpp
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release    # 或用 ./build.sh
cmake --build build -j$(nproc)
# 若头/库不在默认路径：
#   cmake -S . -B build -DRKNN_INC=/opt/rknn/include -DRKNN_LIB=/opt/rknn/lib
# 若 SDK 的 rknn_api.h 太老（没有 rknn_set_core_mask）：
#   cmake -S . -B build -DUSE_CORE_MASK=OFF
```

### 3.3 板端推理
```bash
# GRAY8 原始帧（OV9281 输出格式；裸数据要带宽高）
./build/rknn_v3_detect --model ../v3_960_fp16_dfl_layout.rknn \
    --input frame_1920x1080.raw --width 1920 --height 1080 --layout dfl

# PGM 文件
./build/rknn_v3_detect --model ../v3_960_fp16_dfl_layout.rknn --input frame.pgm --layout dfl

# 500 帧基准（四种 NPU 调度）
./build/rknn_v3_detect --model ... --bench 500 --core-mask auto
./build/rknn_v3_detect --model ... --bench 500 --core-mask 0
./build/rknn_v3_detect --model ... --bench 500 --core-mask 1
./build/rknn_v3_detect --model ... --bench 500 --core-mask 0_1
```

输出（一行 JSON，与 C 模块 `DetectionResult` 对齐）：
```json
{"image":"frame.raw","image_width":1920,"image_height":1080,
 "detections":[{"class_id":2,"class_name":"racket","confidence":0.78,
                "bbox_xyxy":[1201.5,332.0,1388.2,640.7],
                "bbox_xywh":[1201.5,332.0,186.7,308.7]}]}
```
- `bbox_xyxy`：左上 + 右下，**原图像素**
- `bbox_xywh`：**左上角坐标 + 宽高**（与 C++ `Box` 约定一致，不是中心点格式）

## 4. 为什么模型输出是 DFL logits 而不是一个 `[1,7,18900]`

原始 ONNX 的 `output0` 把**框坐标（0–960）**和**类别分数（0–1）**拼进同一个张量。
RKNN 对每个张量只用一个量化尺度，坐标量程会把分数压平（实测反量化后 max 956、mean 162，
INT8 直接检出 0 个框）。

本模型因此把量化出口放在**不与框坐标共享尺度的两个张量**上：
- `dfl` `[1,64,18900]`：4 条边 × 16 个 bin 的距离 logits
- `scores_logits` `[1,3,18900]`：sigmoid 之前的类别 logits

**C++ 侧自己做 DFL 解码**：对每条边的 16 个 bin 做 softmax → 求期望得到距离 →
加上 anchor（网格中心 `(i+0.5)×stride`，stride 8/16/32）→ 得到 960 空间的 xyxy →
再按 letterbox 参数还原到原图。这部分已在 `cpp/rknn_v3_detect_dfl.cpp` 实现，
且其数学在 Python 侧与原始 ONNX 输出**逐类指标完全一致**（见 `EVALUATION_REPORT.md`）。

> 如果你的 runtime 只接受单输出模型，请用 ONNX 自行导出，但**不要**把
> `[1,7,18900]` 那个拼接张量直接拿去做 INT8（原因见上）。

## 5. 包里有什么

```
v3_960_fp16_dfl_layout.rknn          最终 FP16 RKNN 模型
pingpong_yolov8n_gray_3cls_v3_960_960.onnx   V3 原始三分类 ONNX（PC 复现/回退）
README_CAPTAIN.md                    本文件
MODEL_CARD.md                        模型卡（结构/训练/精度/限制）
EVALUATION_REPORT.md                 FP32 vs FP16 逐类评测
DEPLOYMENT_GUIDE.md                  板端部署与性能测试
STATUS.md                            已完成 / 未验证清单
SHA256SUMS.txt                       全部文件校验和
accuracy_fp16_509.json               FP16 在 509 张上的原始评测输出
cpp/rknn_v3_detect_dfl.cpp           RKNN C++ 推理 + DFL 解码
cpp/CMakeLists_dfl.txt               编译脚本（请改名 CMakeLists.txt 或用 -C 指定）
cpp/build.sh                         一键编译
cpp/configs/fp16_960.yaml            转换配置（复现用）
```

## 6. 与现有 C++ 判罚链路的关系（重要）

现有 `perception_engine.cpp` 的统一路径**故意丢弃 ball 类**——ball 的唯一来源是 BallTrack。
本包的程序是**独立测试/部署工具，输出三类**，**未接入正式判罚链路**。
若要接入并启用 YOLO 的 ball 输出，会与 BallTrack 形成双球源，**必须先经 B 模块评审**。

## 7. 已知限制

1. **板端未验证**：没有 AFH03 实物，NPU 精度与 FPS 都未测。
2. **C++ 未编译**：本机无编译器；算法在 Python 侧做过数值核验，但**代码本身没有过编译**。
3. **OV9281 未接入**：只支持离线 GRAY8 帧（raw/pgm）。
4. **Ball 召回偏低**（0.510）：小球在 960 输入下只有 9.6–16.9 px，是长期瓶颈。
5. 验证集是**历史开发验证集**（V2–V7 多轮使用），不是独立测试集。

## 8. 快速排查

| 现象 | 处理 |
| --- | --- |
| `rknn_init failed` | 模型与 `librknnrt.so` 版本不匹配；从同版本 toolkit 拷运行库 |
| 一堆框位置乱飞 | 确认 `--layout dfl`；确认输入确实是 GRAY8 裸数据 |
| 没有任何框 | 检查 letterbox 是否 114 填充、是否重复除了 255（RKNN config 里已做 mean/std） |
| `core_mask` 无效 | 老 SDK 用 `-DUSE_CORE_MASK=OFF` 重新编译 |
| 报 `rknn_set_core_mask` 未定义 | 同上 |
