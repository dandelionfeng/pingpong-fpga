﻿# DEPLOYMENT_GUIDE — AFH03 / RK3576J 部署步骤

本包**没有板端实测数据**。以下命令按 Rockchip 官方流程编写，请在自己板子上逐条验证。

## 1. 环境要求

| 层 | 要求 |
|---|---|
| 芯片 | Rockchip **RK3576**（AFH03） |
| OS | Linux（板厂固件），有 `/dev/rknpu*` |
| RKNN Runtime | **`librknnrt.so` 版本 ≥ 转换端 toolkit（2.5.0）**。版本低于模型版本时 `rknn_init` 会失败 |
| 头文件 | `rknn_api.h`（与 runtime 同版本） |
| 编译 | `cmake` + `g++`（或用交叉工具链） |
| 可选 | `rknn-toolkit-lite2`（Python 快速验证） |

检查命令：
```bash
uname -a
cat /proc/device-tree/compatible            # 应含 rockchip,rk3576
ls /dev | grep -i rknpu
strings /usr/lib/librknnrt.so | grep -i -m3 version
ldconfig -p | grep rknn
```

## 2. 传模型上板

```bash
adb push v3_960_fp16_dfl_layout.rknn /userdata/     # 或 scp
sha256sum /userdata/v3_960_fp16_dfl_layout.rknn
# 必须等于：
# 1bcff6ff23f1a26428742e6a8e7c9acaf5b130171dbf2072cbaace6c62bcad0b
```

## 3. 编译

```bash
cd /userdata/cpp
# 本包的 CMakeLists 文件名是 CMakeLists_dfl.txt，先改名或用 -C 指定
mv CMakeLists_dfl.txt CMakeLists.txt
./build.sh
# 头/库不在默认路径时：
#   ./build.sh -DRKNN_INC=/opt/rknn/include -DRKNN_LIB=/opt/rknn/lib
# 老 SDK（无 rknn_set_core_mask）：
#   ./build.sh -DUSE_CORE_MASK=OFF
```

产物：`build/rknn_v3_detect`

## 4. 单帧推理

准备一帧 **GRAY8 裸数据**（OV9281 直出格式：1920×1080 单通道、无头）或 `.pgm`：

```bash
./build/rknn_v3_detect --model /userdata/v3_960_fp16_dfl_layout.rknn \
    --input /userdata/frame_1920x1080.raw --width 1920 --height 1080 --layout dfl
```

程序会先打印模型信息（每个输出的形状/类型/量化类型），再输出一行检测 JSON。

**首次自检三件事**：
1. 能打印出 `outputs=` 且能找到 64 通道与 3 通道输出；
2. 检测框位置合理（可叠加回图像看）；
3. 三类都能出现（换含球/手的帧）。

## 5. 性能测试

```bash
# 每个 core-mask 各跑 500 帧
for M in auto 0 1 0_1; do
  ./build/rknn_v3_detect --model /userdata/v3_960_fp16_dfl_layout.rknn \
      --input /userdata/frame.raw --width 1920 --height 1080 \
      --bench 500 --core-mask $M
done
```

输出字段：
```json
{"frames":500,"pre_ms":..,"npu_ms":..,"post_ms":..,
 "total_mean_ms":..,"total_p50_ms":..,"total_p95_ms":..,"fps":..}
```

同时采样（另开终端）：
```bash
while true; do cat /sys/kernel/debug/rknpu/load; sleep 1; done   # NPU 负载
top -b -n1 | head -15                                            # CPU
cat /sys/class/thermal/thermal_zone*/temp                         # 温度
```

**要报告三层的数字**（不要混为一谈）：
- A. NPU 纯推理 = `npu_ms`
- B. 预处理 + NPU + 后处理 = `total_mean_ms`
- C. 相机到结果 = 还需要加上采集/传输（本程序不含相机）

官方参考的 "YOLOv8n 640 INT8 单核 90.2 FPS" 是**纯推理、640 输入、官方模型**，与
本模型（960、三分类、含预处理）**不可直接比较**。

## 6. 板端精度复测（可选但推荐）

把 509 张验证图逐帧跑一遍，保存 JSON，然后按下面口径统计（与 PC 完全一致）：

- 匹配：类内一对一贪心，IoU ≥ 0.5
- 阈值：ball 0.20 / hand 0.25 / racket 0.25
- 指标：每类 P / R / F1 / AP50（101 点插值）

验收线（FP16 期望接近 PC 的 0.810/0.510、0.692/0.559、0.764/0.756）：
若板端 Ball Recall 掉到 0.45 以下，先查预处理是否与 PC 一致（letterbox 114、不要重复除 255）。

## 7. 常见错误

| 现象 | 原因 | 处理 |
|---|---|---|
| `rknn_init failed: -1` | 版本不匹配 / 文件损坏 | 比对 `librknnrt.so` 版本；`sha256sum` |
| `rknn_init failed: -4` | 内存不足 | 关掉其它 NPU 进程 |
| 找不到 64 通道输出 | 加载了错误的模型 | 确认是 `v3_960_fp16_dfl_layout.rknn` |
| 框位置整体偏移 | letterbox 参数或 `--layout` 选错 | 必须 `--layout dfl`；确认 pad=114 |
| 分数全是 0/1 | 重复归一化 | RKNN config 已含 mean/std，代码不再除 255 |
| `core_mask` 无变化 | 单核已打满 | 实测四种，不要预设双核更快 |
