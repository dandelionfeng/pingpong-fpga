﻿# STATUS — 已完成 / 未验证

日期：2026-10-30　模型：V3 Unified YOLOv8n · FP16 RKNN

## ✅ 已完成（有实测证据）

| 项 | 证据 |
|---|---|
| V3 三分类权重未改动 | ONNX sha256 `b779c88e…` 与交付前一致 |
| **RKNN FP16 转换成功** | `v3_960_fp16_dfl_layout.rknn`，13,038,908 B，sha256 `1bcff6ff…cad0b`，由 rknn-toolkit2 **2.5.0** 生成 |
| 输出布局修复（DFL logits + 类别 logits） | 计算图审计：`output0 = Concat(box, sigmoid(scores))` 是 INT8/量化的根因 |
| 拆分前后数值一致 | `cat(boxes,scores)` vs 原 `output0` 最大差 **0.0**；三种解码逐类指标完全相同 |
| **509 张精度评测（PC/模拟器）** | Ball 0.810/0.510，Hand 0.692/0.559，Racket 0.764/0.756（P/R） |
| FP16 vs FP32 差异 | ≤1.3 个百分点，Ball/Racket 召回完全相同 |
| C++ DFL 解码源码 | `cpp/rknn_v3_detect_dfl.cpp`，支持 `--layout dfl|split`、`--core-mask`、`--bench` |
| C++ 算法数值核验（Python 侧） | DFL 解码结果与原始 ONNX 输出**逐类指标一致** |

## ❌ 未验证（BLOCKED，不得宣称）

| 项 | 状态 | 原因 |
|---|---|---|
| **AFH03 板端加载 RKNN** | ❌ 未做 | 无实物连接（无 adb/USB 设备，网络不可达） |
| **板端精度** | ❌ 未测 | 同上；本包精度全部来自 PC/模拟器 |
| **NPU FPS（单核/双核）** | ❌ 未测 | 同上 |
| **NPU 纯推理延迟 / P50 / P95** | ❌ 未测 | 同上 |
| **完整流水线 FPS** | ❌ 未测 | 同上（且本包不含相机采集） |
| **C++ 真实编译** | ❌ 未做 | 本机无 cmake/cl/g++，且需板端 aarch64 + `librknnrt.so` |
| **OV9281 接入验证** | ❌ 未做 | 无相机、无板子 |
| **RGA/FPGA 预处理** | ❌ 未做 | 仅提出方案 |
| **与 BallTrack 联调** | ❌ 未做 | 需 B 模块评审（双球源冲突） |
| **逐张量 scale / zero-point** | ❌ 未导出 | 需板端 `rknn_query(RKNN_QUERY_OUTPUT_ATTR)`；C++ 已打印 `qnt_type` |

## ⚠ 需注意

- **INT8 未作为默认交付**：Ball Recall 0.470 < 0.49 门槛（Hand/Racket 达标）。
  INT8 模型与修复报告在仓库 `artifacts/rknn_deployment/v3_960_int8_v2/`。
- 验证集是**历史开发验证集**（V2–V7 多轮使用），不是独立测试集。
- 官方 "90.2 FPS" 是 640 INT8 单核纯推理的官方模型数据，与本模型不可比。

## 一句话

**模型转换这一环是真的做完了；板端那一环一点都没做。**
拿到 AFH03 后按 `DEPLOYMENT_GUIDE.md` 走一遍，把 §5 的三层延迟和 §6 的板端精度补上即可。
