# 最终检测器交付说明（MODE A 推荐）

**状态：实验候选（EXPERIMENTAL）** —— 已通过固定验证集的逐类评测与 CPU 基准，
**没有**真实 OV9281 视频验证，**没有** RKNN/NPU 与板端测试。

## 1. 一句话结论

**采用 MODE A（单个 V3 三分类 YOLO）**。双 YOLO（MODE B）在本项目数据上 Ball 指标崩溃
（F1 0.025 vs 0.630），不符合任何交付条件。

| | MODE A `unified_v3` | MODE B `dual_yolo` |
| --- | --- | --- |
| 模型 | V3 一个 | ball_v6 + V3 两个 |
| Ball F1 / AP50 | **0.630 / 0.492** | 0.025 / 0.005 |
| Ball 空帧误报率 | **0.0%（0/409）** | **44.0%（180/409）** |
| 每帧前向 | 1 次 | 2 次 |
| CPU 均值延迟（本机受干扰） | **208 ms** | 812 ms |
| 建议 | ✅ **采用** | ❌ 不采用 |

## 2. 目录内容

| 文件 | 说明 |
| --- | --- |
| `pingpong_yolov8n_gray_3cls_v3_960.onnx` | **主模型**（MODE A 唯一模型）：`[1,3,960,960]` → `[1,7,18900]` |
| `ball_v6_round2.onnx` | MODE B 的球专项模型（**仅备用**，本域不可用） |
| `unified_detector.py` | 统一推理入口：`--backend unified_v3` / `dual_yolo`，同一输出协议 |
| `bench_and_eval.py` | 逐类精度评测 + CPU 基准 |
| `MODEL_MANIFEST.md` | 版本、形状、SHA256 |
| `ACCURACY_COMPARISON.md` | MODE A vs MODE B 逐类对比 |
| `PERFORMANCE_REPORT.md` | CPU 延迟/FPS/内存、测量条件、GPU/RKNN 状态 |
| `sample_*.jpg` | 检测示例 |
| `SHA256SUMS.txt` | 校验和 |

## 3. 怎么跑

```powershell
# 单张 / 文件夹
python unified_detector.py infer --backend unified_v3 --source frame.jpg --out out
python unified_detector.py infer --backend unified_v3 --source frames\ --out out

# 备用双模型（不推荐）
python unified_detector.py infer --backend dual_yolo --source frames\ --out out

# 精度评测（同一 509 图）
python bench_and_eval.py eval --backend unified_v3 --val <数据集目录>
# CPU 基准
python bench_and_eval.py bench --backend unified_v3 --val <数据集目录> --n 150
```

依赖：`numpy`、`opencv-python`、`onnxruntime`（CPU 即可）。

## 4. 输入 / 输出协议

**输入**：GRAY8 单通道。处理与训练完全一致：
`gray → 复制成 3 通道 → letterbox 到 960（填充 114）→ /255 → NCHW float32`。

**输出**（每个检测框同时给两种坐标格式，避免与 C++ 的 xywh 约定混淆）：

```json
{
  "backend": "unified_v3",
  "image_width": 1920, "image_height": 1080,
  "detections": [
    {"class_id": 0, "class_name": "ball", "confidence": 0.56,
     "bbox_xyxy": [968.48, 398.87, 993.81, 423.97],
     "bbox_xywh": [968.48, 398.87, 25.33, 25.10]}
  ]
}
```

- 类别固定：**0 = ball，1 = hand，2 = racket**（两种模式一致）
- `bbox_xyxy`：左上 + 右下，单位原图像素
- `bbox_xywh`：**x,y = 左上角**，w,h = 宽高（与 C++ `Box` 约定一致，**不是中心点格式**）
- NMS：类内 IoU 0.5，`max_det` 60

## 5. 阈值（在验证集上选定后冻结）

| 类别 | 阈值 | 依据 |
| --- | ---: | --- |
| Ball | **0.20** | F1 峰值（0.630）；0.25 时为 0.618 |
| Hand | 0.25 | F1 0.618 |
| Racket | **0.25** | F1 0.758（比 C++ 默认 0.30 的 0.752 略优） |

> ⚠ 阈值是**工作点选择**，不是模型能力提升。

## 6. 与现有 C++ 管线的兼容性（重要）

现有 `perception_engine.cpp` 的统一路径已经：
- 从输出形状自动推导类别数（`num_classes = out_shape[1] - 4`）→ **支持 3 类**；
- 对 `hand` / `racket` 分别套 `hand_conf` / `racket_conf`；
- **故意丢弃 `ball` 类**（注释写明：ball 唯一来源是 BallTrack）。

因此部署分两种：

| 方案 | 改动 | 说明 |
| --- | --- | --- |
| **A1（零代码改动，推荐）** | 只替换 ONNX，`racket_conf` 0.30 → **0.25** | ball 仍由 BallTrack 提供，接口不变 |
| A2（需要审批） | 在 C++ 中放行统一模型的 ball 输出 | 属于**接口变更**，会与 BallTrack 形成双球源竞争，需 B 模块负责人复核 |

**本轮未修改任何 C++ 文件**，上述为说明与建议。

## 7. 已知限制

1. **无真实 OV9281 视频验证**；所有数字来自历史开发验证集（509 图）。
2. 该 val 已被 V2–V7 多轮用于决策，**只能算历史开发验证集，不是独立测试集**。
3. Ball 召回 0.510 仍是短板（小目标 + 正样本密度不足）。
4. **无 GPU 加速**：本机 ONNX Runtime 只有 CPU/Azure provider，无 CUDA EP。
5. **无 RKNN/NPU 转换、无板端测试、无 C++ 编译验证**（本机无编译器）。
