﻿# MODEL_MANIFEST — 模型版本清单

| 角色 | 文件 | 大小(B) | SHA256 | 输入 | 输出 | 类别 |
|---|---|---|---|---|---|---|
| **主模型 (MODE A)** | `pingpong_yolov8n_gray_3cls_v3_960.onnx` | 12,161,114 | `b779c88e08f8bd15275e301c00bcbfb9c737fc22fa4ef1c358008f0b932254ba` | [1,3,960,960] | [1,7,18900] | 0=ball 1=hand 2=racket |
| 备用 (MODE B 球) | `ball_v6_round2.onnx` | 12,159,554 | `d32b98d6a5a986b527654a7a34656a96d6d79a2702440bfffb36cf49dd685383` | [1,3,960,960] | [1,5,18900] | 0=ball（单类） |

## 训练来源（主模型 V3）
- 权重: `artifacts/runs/unified_3cls_v3b/weights/best.pt` (sha256 `35e72c114e5c0fe5dc822cd826a5aa6be303bc6516d38317979b71bc5e455b23`)
- 数据: `pingpong_unified_3cls_v4`，train 4,431 图（ball 2,499 / hand 3,698 / racket 4,790）
- 训练: YOLOv8n 960, batch 12, AdamW 3e-4, 15/16 epoch, best epoch 9, 32 min, RTX 4060
- 类别顺序在三轮交付中保持不变（0/1/2），未做过 remap

## 备用模型的已知问题
`ball_v6_round2` 在 BNDSTT 近景域训练，在本项目 val（1920×1080 全台视角）上实测：
Ball TP 6 / FP 367 / FN 94，F1 0.025，409 张无球帧中 180 张误报（44%）。
**仅作为历史资产保留，不建议在任何模式中使用。**
