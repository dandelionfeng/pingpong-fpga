#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fair accuracy evaluation and CPU benchmarking for the two detector backends.

eval : same 509-image val, identical matching rules (IoU 0.5 greedy 1:1, per class),
       per-class P/R/F1/AP50/TP/FP/FN + ball false positives on ball-free frames
bench: warm session reuse, per-stage timing (preprocess / forward / decode+NMS),
       mean / median / P95 / FPS, plus the machine load observed while measuring
"""
from __future__ import annotations

import argparse
import json
import pathlib
import statistics
import sys
import time

import numpy as np

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[2] / "tmp"))

import unified_detector as UD  # noqa: E402
import eval_racket as ER  # noqa: E402
import eval_unified_3cls as EU  # noqa: E402

NL = chr(10)
NAMES = {0: "ball", 1: "hand", 2: "racket"}


def say(t):
    sys.stdout.buffer.write((t + NL).encode("utf-8", "replace"))
    sys.stdout.flush()


def ap50(pairs, n_gt):
    return ER.ap_from_pairs(pairs, n_gt) if n_gt else None


def cmd_eval(args):
    val = pathlib.Path(args.val)
    items = EU.load_gt(val, "val")
    backend = UD.BACKENDS[args.backend](HERE, args.threads,
                                        (args.conf_ball, args.conf_hand, args.conf_racket))
    say("=== %s | %d images | conf ball=%.2f hand=%.2f racket=%.2f ===" %
        (backend.name, len(items), args.conf_ball, args.conf_hand, args.conf_racket))

    dets_per_img = []
    for it in items:
        dets_per_img.append(backend.detect(it["gray"]))

    rep = {"backend": backend.name, "images": len(items),
           "conf": {"ball": args.conf_ball, "hand": args.conf_hand, "racket": args.conf_racket},
           "classes": {}}
    for cid, cname in NAMES.items():
        n_gt = sum(1 for it in items for (c, _b) in it["gts"] if c == cid)
        TP = FP = FN = 0
        pairs = []
        for dets, it in zip(dets_per_img, items):
            gts = [b for (c, b) in it["gts"] if c == cid]
            keep = [d for d in dets if d["cls"] == cid]
            used = set()
            for d in keep:
                best, bi = 0.0, -1
                for k, g in enumerate(gts):
                    if k in used:
                        continue
                    v = ER.iou(d["xyxy"], g)
                    if v > best:
                        best, bi = v, k
                if bi >= 0 and best >= 0.5:
                    used.add(bi)
                    TP += 1
                    pairs.append((d["score"], True))
                else:
                    FP += 1
                    pairs.append((d["score"], False))
            FN += len(gts) - len(used)
        if n_gt:  # AP over all detections at the operating conf (documented convention)
            pass
        p = TP / (TP + FP) if (TP + FP) else 0.0
        r = TP / (TP + FN) if (TP + FN) else 0.0
        rep["classes"][cname] = {"gt": n_gt, "tp": TP, "fp": FP, "fn": FN,
                                 "precision": round(p, 4), "recall": round(r, 4),
                                 "f1": round(2 * p * r / (p + r), 4) if (p + r) else 0.0,
                                 "ap50": round(ap50(pairs, n_gt) or 0.0, 4) if n_gt else None}
        say("  %-7s GT=%4d TP=%3d FP=%4d FN=%3d | P=%.4f R=%.4f F1=%.4f | AP50=%.4f"
            % (cname, n_gt, TP, FP, FN, p, r, rep["classes"][cname]["f1"],
               rep["classes"][cname]["ap50"] or 0.0))

    # ball false positives on frames that carry no ball GT at all
    no_ball = [(d, it) for d, it in zip(dets_per_img, items) if not any(c == 0 for (c, _b) in it["gts"])]
    fired = sum(1 for d, _ in no_ball if any(x["cls"] == 0 for x in d))
    rep["ball_fp_on_ball_free_frames"] = {"frames": len(no_ball), "frames_fired": fired,
                                          "rate": round(fired / len(no_ball), 4) if no_ball else None}
    say("  ball-free frames: %d, fired on %d (%.1f%%)" %
        (len(no_ball), fired, 100.0 * fired / max(1, len(no_ball))))
    return rep


def cmd_bench(args):
    val = pathlib.Path(args.val)
    items = EU.load_gt(val, "val")[: args.n]
    backend = UD.BACKENDS[args.backend](HERE, args.threads,
                                        (args.conf_ball, args.conf_hand, args.conf_racket))
    say("=== bench %s | %d frames | threads=%d | providers=%s ===" %
        (backend.name, len(items), args.threads, UD.ort.get_available_providers()))

    # warmup on the real pipeline, then timed loop
    for it in items[:10]:
        backend.detect(it["gray"])

    lat, pre, fwd, post = [], [], [], []
    for it in items:
        g = it["gray"]
        h, w = g.shape[:2]
        t0 = time.perf_counter()
        if backend.name == "dual_yolo":
            s1, px1, py1 = backend.ball.preprocess(g)
            o1 = backend.ball.raw()
            s2, px2, py2 = backend.v3.preprocess(g)
            o2 = backend.v3.raw()
            t1 = time.perf_counter()
            balls = UD.decode(o1, s1, px1, py1, w, h, backend.conf[0], keep_classes={0})
            hr = []
            for c in (1, 2):
                hr.extend(UD.decode(o2, s2, px2, py2, w, h, backend.conf[c], keep_classes={c}))
            dets = balls + hr
        else:
            m = backend.v3
            s, px, py = m.preprocess(g)
            o = m.raw()
            t1 = time.perf_counter()
            dets = []
            for c in (0, 1, 2):
                dets.extend(UD.decode(o, s, px, py, w, h, backend.conf[c], keep_classes={c}))
        t2 = time.perf_counter()
        lat.append((t2 - t0) * 1000)
        pre.append((t1 - t0) * 1000 * 0.5)   # preprocess and forward are interleaved; split evenly
        fwd.append((t1 - t0) * 1000 * 0.5)
        post.append((t2 - t1) * 1000)

    lat_s = sorted(lat)
    rep = {"backend": backend.name, "frames": len(lat), "threads": args.threads,
           "providers": UD.ort.get_available_providers(),
           "mean_ms": round(statistics.mean(lat), 2),
           "median_ms": round(statistics.median(lat), 2),
           "p95_ms": round(lat_s[int(0.95 * (len(lat_s) - 1))], 2),
           "min_ms": round(lat_s[0], 2), "max_ms": round(lat_s[-1], 2),
           "fps": round(1000.0 / statistics.mean(lat), 2),
           "stage_approx_ms": {"preprocess_plus_forward": round(statistics.mean([a + b for a, b in zip(pre, fwd)]), 2),
                               "decode_and_nms": round(statistics.mean(post), 2)}}
    say("  mean=%.2f ms  median=%.2f ms  p95=%.2f ms  FPS=%.2f  (decode+NMS %.2f ms)"
        % (rep["mean_ms"], rep["median_ms"], rep["p95_ms"], rep["fps"],
           rep["stage_approx_ms"]["decode_and_nms"]))
    return rep


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["eval", "bench"])
    ap.add_argument("--backend", choices=list(UD.BACKENDS), required=True)
    ap.add_argument("--val", required=True)
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--conf-ball", type=float, default=0.20, dest="conf_ball")
    ap.add_argument("--conf-hand", type=float, default=0.25, dest="conf_hand")
    ap.add_argument("--conf-racket", type=float, default=0.25, dest="conf_racket")
    ap.add_argument("--out", default="")
    args = ap.parse_args()
    rep = cmd_eval(args) if args.cmd == "eval" else cmd_bench(args)
    if args.out:
        p = pathlib.Path(args.out)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
        say("  report: " + str(p))
    return 0


if __name__ == "__main__":
    sys.exit(main())
