#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Unified ping-pong detector: one entry point, two backends, one output contract.

  --backend unified_v3   one YOLOv8n-3cls model emits ball(0) / hand(1) / racket(2)
  --backend dual_yolo    ball_v6 (ball only) + V3 (hand+racket only, its ball class dropped)

Contract (matches the C module DetectionResult semantics):
  * input is GRAY8; it is replicated to 3 identical channels, letterboxed to 960 with pad 114,
    scaled to /255 and fed as NCHW float32 - exactly what the models were trained on
  * output boxes are in ORIGINAL image pixels, both xyxy and xywh are provided
    (xywh keeps the C++ backend convention: x,y = top-left corner, w,h = size)
  * class ids are fixed: 0 = ball, 1 = hand, 2 = racket, in both backends

Usage:
  python unified_detector.py infer --backend unified_v3 --source img.jpg --out out/
  python unified_detector.py eval  --backend dual_yolo --val <dataset dir>
  python unified_detector.py bench --backend unified_v3 --n 200
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys
import time

import cv2
import numpy as np
import onnxruntime as ort

NAMES = {0: "ball", 1: "hand", 2: "racket"}
HERE = pathlib.Path(__file__).resolve().parent
SZ = 960
PAD = 114


# ----------------------------------------------------------------------------- models
class Model:
    """One ONNX session, created once and reused for every frame."""

    def __init__(self, path: pathlib.Path, threads: int = 4):
        so = ort.SessionOptions()
        so.intra_op_num_threads = threads
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        self.sess = ort.InferenceSession(str(path), sess_options=so,
                                         providers=["CPUExecutionProvider"])
        self.iname = self.sess.get_inputs()[0].name
        self.oname = self.sess.get_outputs()[0].name
        shp = self.sess.get_inputs()[0].shape
        if len(shp) != 4 or shp[1] != 3:
            raise SystemExit("unexpected input shape %s for %s" % (shp, path.name))
        self.size = int(shp[2])
        self.out_ch = int(self.sess.get_outputs()[0].shape[1])   # 4 + nc
        self.nc = self.out_ch - 4
        # preallocated, reused buffers (no per-frame allocation of the input tensor)
        self.buf = np.zeros((1, 3, self.size, self.size), np.float32)
        self.canvas = np.full((self.size, self.size), PAD, np.uint8)

    def preprocess(self, gray: np.ndarray):
        """GRAY8 -> letterboxed NCHW float32 in self.buf. Returns (scale, pad_x, pad_y)."""
        h, w = gray.shape[:2]
        s = min(self.size / w, self.size / h)
        nw, nh = max(1, int(round(w * s))), max(1, int(round(h * s)))
        if (nw, nh) != (w, h):
            rs = cv2.resize(gray, (nw, nh), dst=np.empty((nh, nw), np.uint8),
                            interpolation=cv2.INTER_LINEAR)
        else:
            rs = gray
        px, py = (self.size - nw) // 2, (self.size - nh) // 2
        self.canvas[:] = PAD
        self.canvas[py:py + nh, px:px + nw] = rs
        # gray3 in one shot: broadcast the single channel into the 3 plane buffer
        np.divide(self.canvas, 255.0, out=self.buf[0, 0], dtype=np.float32)
        self.buf[0, 1] = self.buf[0, 0]
        self.buf[0, 2] = self.buf[0, 0]
        return s, px, py

    def raw(self):
        return self.sess.run([self.oname], {self.iname: self.buf})[0][0]


def decode(out: np.ndarray, s, px, py, w0, h0, conf, iou=0.5, max_det=60, keep_classes=None):
    """Decode one model output into original-image-pixel boxes, class-aware NMS."""
    scores = out[4:]
    cls = scores.argmax(axis=0)
    sc = scores.max(axis=0)
    idx = np.nonzero(sc >= conf)[0]
    if idx.size == 0:
        return []
    if keep_classes is not None:
        idx = idx[np.isin(cls[idx], list(keep_classes))]
        if idx.size == 0:
            return []
    idx = idx[np.argsort(-sc[idx])][:max_det * 10]
    b = out[:4, idx]
    x1 = np.clip((b[0] - b[2] / 2 - px) / s, 0, w0)
    y1 = np.clip((b[1] - b[3] / 2 - py) / s, 0, h0)
    x2 = np.clip((b[0] + b[2] / 2 - px) / s, 0, w0)
    y2 = np.clip((b[1] + b[3] / 2 - py) / s, 0, h0)
    ok = (x2 - x1 >= 1) & (y2 - y1 >= 1)
    dets = []
    for i, a, c, d, e in zip(idx[ok], x1[ok], y1[ok], x2[ok], y2[ok]):
        dets.append({"cls": int(cls[i]), "score": float(sc[i]), "xyxy": [float(a), float(c), float(d), float(e)]})
    # class-aware NMS
    out2 = []
    for c in sorted({x["cls"] for x in dets}):
        grp = sorted([x for x in dets if x["cls"] == c], key=lambda x: -x["score"])
        kept = []
        for cand in grp:
            ax1, ay1, ax2, ay2 = cand["xyxy"]
            dup = False
            for k in kept:
                bx1, by1, bx2, by2 = k["xyxy"]
                iw = max(0.0, min(ax2, bx2) - max(ax1, bx1))
                ih = max(0.0, min(ay2, by2) - max(ay1, by1))
                inter = iw * ih
                if inter > 0:
                    ua = (ax2 - ax1) * (ay2 - ay1) + (bx2 - bx1) * (by2 - by1) - inter
                    if ua > 0 and inter / ua > iou:
                        dup = True
                        break
            if not dup:
                kept.append(cand)
            if len(kept) >= max_det:
                break
        out2.extend(kept)
    out2.sort(key=lambda x: -x["score"])
    return out2


# ----------------------------------------------------------------------------- backends
class UnifiedV3:
    name = "unified_v3"
    desc = "V3 3-class model: ball+hand+racket in one forward"

    def __init__(self, models_dir: pathlib.Path, threads: int = 4,
                 conf=(0.20, 0.25, 0.25)):
        self.v3 = Model(models_dir / "pingpong_yolov8n_gray_3cls_v3_960.onnx", threads)
        self.conf = dict(zip((0, 1, 2), conf))

    def detect(self, gray):
        h, w = gray.shape[:2]
        s, px, py = self.v3.preprocess(gray)
        out = self.v3.raw()
        dets = []
        for c in (0, 1, 2):
            dets.extend(decode(out, s, px, py, w, h, self.conf[c], keep_classes={c}))
        return dets


class DualYolo:
    name = "dual_yolo"
    desc = "ball_v6 for ball + V3 for hand/racket (V3 ball output dropped)"

    def __init__(self, models_dir: pathlib.Path, threads: int = 4,
                 conf=(0.20, 0.25, 0.25)):
        self.ball = Model(models_dir / "ball_v6_round2.onnx", threads)
        self.v3 = Model(models_dir / "pingpong_yolov8n_gray_3cls_v3_960.onnx", threads)
        self.conf = dict(zip((0, 1, 2), conf))

    def detect(self, gray):
        h, w = gray.shape[:2]
        # ball model: its own session/buffer, single class -> everything it emits is a ball
        s1, px1, py1 = self.ball.preprocess(gray)
        o1 = self.ball.raw()
        balls = decode(o1, s1, px1, py1, w, h, self.conf[0], keep_classes={0})
        # V3: same preprocessed frame layout, but hand+racket only (ball dropped on purpose)
        s2, px2, py2 = self.v3.preprocess(gray)
        o2 = self.v3.raw()
        hr = []
        for c in (1, 2):
            hr.extend(decode(o2, s2, px2, py2, w, h, self.conf[c], keep_classes={c}))
        return balls + hr


BACKENDS = {"unified_v3": UnifiedV3, "dual_yolo": DualYolo}


# ----------------------------------------------------------------------------- io helpers
def read_gray(path: pathlib.Path):
    buf = np.fromfile(str(path), dtype=np.uint8)
    im = cv2.imdecode(buf, cv2.IMREAD_UNCHANGED) if buf.size else None
    if im is None:
        return None
    return cv2.cvtColor(im, cv2.COLOR_BGR2GRAY) if im.ndim == 3 else im


def to_public(dets, w, h):
    """Normalise to the C-module contract: xyxy + xywh (top-left corner) in image pixels."""
    out = []
    for d in dets:
        x1, y1, x2, y2 = d["xyxy"]
        out.append({"class_id": int(d["cls"]), "class_name": NAMES.get(d["cls"], "?"),
                    "confidence": round(float(d["score"]), 4),
                    "bbox_xyxy": [round(x1, 2), round(y1, 2), round(x2, 2), round(y2, 2)],
                    "bbox_xywh": [round(x1, 2), round(y1, 2), round(x2 - x1, 2), round(y2 - y1, 2)]})
    return {"image_width": w, "image_height": h, "detections": out}


COLOUR = {0: (0, 255, 255), 1: (0, 220, 0), 2: (0, 0, 255)}


def draw(gray, dets):
    vis = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    for d in dets:
        x1, y1, x2, y2 = [int(round(v)) for v in d["xyxy"]]
        col = COLOUR.get(d["cls"], (255, 255, 255))
        cv2.rectangle(vis, (x1, y1), (x2, y2), col, 2)
        cv2.putText(vis, "%s %.2f" % (NAMES.get(d["cls"], "?"), d["score"]),
                    (x1, max(14, y1 - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, col, 2)
    return vis


# ----------------------------------------------------------------------------- commands
def cmd_infer(args):
    backend = BACKENDS[args.backend](pathlib.Path(args.models), args.threads,
                                     *((args.conf_ball, args.conf_hand, args.conf_racket),))
    src = pathlib.Path(args.source)
    if not src.exists():
        raise SystemExit("source not found: %s" % src)
    out = pathlib.Path(args.out)
    (out / "vis").mkdir(parents=True, exist_ok=True)
    files = sorted(p for p in src.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}) \
        if src.is_dir() else [src]
    n = 0
    for f in files:
        g = read_gray(f)
        if g is None:
            continue
        h, w = g.shape[:2]
        t0 = time.perf_counter()
        dets = backend.detect(g)
        ms = (time.perf_counter() - t0) * 1000
        rec = to_public(dets, w, h)
        rec["backend"] = backend.name
        rec["latency_ms"] = round(ms, 2)
        (out / (f.stem + ".json")).write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
        ok, enc = cv2.imencode(".jpg", draw(g, dets), [int(cv2.IMWRITE_JPEG_QUALITY), 92])
        enc.tofile(str(out / "vis" / (f.stem + ".jpg")))
        print("%-40s ball=%d hand=%d racket=%d  %.1f ms" % (
            f.name[:40], sum(1 for d in dets if d["cls"] == 0),
            sum(1 for d in dets if d["cls"] == 1), sum(1 for d in dets if d["cls"] == 2), ms))
        n += 1
    print("SUMMARY backend=%s frames=%d out=%s" % (backend.name, n, out))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["infer", "eval", "bench"])
    ap.add_argument("--backend", choices=list(BACKENDS), default="unified_v3")
    ap.add_argument("--models", default=str(HERE))
    ap.add_argument("--source", default="")
    ap.add_argument("--out", default="out")
    ap.add_argument("--val", default="")
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--conf-ball", type=float, default=0.20, dest="conf_ball")
    ap.add_argument("--conf-hand", type=float, default=0.25, dest="conf_hand")
    ap.add_argument("--conf-racket", type=float, default=0.25, dest="conf_racket")
    args = ap.parse_args()
    if args.cmd == "infer":
        return cmd_infer(args)
    raise SystemExit("cmd %s is implemented in bench_and_eval.py" % args.cmd)


if __name__ == "__main__":
    sys.exit(main())
